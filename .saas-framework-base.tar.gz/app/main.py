from pathlib import Path

from fastapi import Depends, FastAPI, Request, Response
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.auth import get_current_user
from app.core.middleware import SecurityHeadersMiddleware
from app.core.config import settings
from app.core.database import get_session, init_db
from app.core.exceptions import registrar_handlers
from app.core.modules import discover_modules
from app.core.templating import render
from app.models import Auditoria, Empresa, Log, Usuario

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
)

app.add_middleware(SecurityHeadersMiddleware)
registrar_handlers(app)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")


@app.get("/live", tags=["Health"])
def live() -> dict:
    """Liveness (§39.21) — o processo está de pé.

    Não toca em dependência alguma de propósito: se o banco cair, o
    orquestrador não deve reiniciar o container, só parar de mandar tráfego
    (é o que o /ready faz).
    """
    return {"status": "alive", "app": settings.app_name}


@app.get("/ready", tags=["Health"])
def ready(response: Response, db: Session = Depends(get_session)) -> dict:
    """Readiness (§39.21) — pronto para receber tráfego.

    Verifica banco, cache, disco e armazenamento. Devolve 503 quando algo
    essencial está fora, para o balanceador tirar a instância da rotação.
    """
    from app.core.health import verificar_dependencias

    checagens, pronto = verificar_dependencias(db)
    if not pronto:
        response.status_code = 503
    return {"status": "ready" if pronto else "not_ready",
            "app": settings.app_name, "checks": checagens}


@app.get("/health", tags=["Health"])
def health(db: Session = Depends(get_session)) -> dict:
    """Resumo do estado (§39.21) — sempre 200, para painéis e uptime checks."""
    from app.core.health import verificar_dependencias

    checagens, pronto = verificar_dependencias(db)
    return {"status": "ok" if pronto else "degraded",
            "app": settings.app_name,
            "database": checagens["database"]["status"],
            "checks": checagens}


@app.get("/logo", include_in_schema=False)
def logo(request: Request, db: Session = Depends(get_session)):
    """Logo da empresa (§22) — usada na sidebar e nas telas de login."""
    from fastapi import HTTPException
    from fastapi.responses import FileResponse

    from app.core.auth import user_from_request
    from app.core.config_service import get_config
    from app.core.storage import absolute_path
    from app.models import Arquivo

    usuario = user_from_request(request, db)
    empresa_id = usuario.tenant_id if usuario else 1
    arquivo_id = get_config(db, "logo_arquivo_id", empresa_id=empresa_id)
    if not arquivo_id:
        raise HTTPException(status_code=404)
    arquivo = db.get(Arquivo, int(arquivo_id))
    if arquivo is None or arquivo.deleted_at is not None:
        raise HTTPException(status_code=404)
    path = absolute_path(arquivo)
    if not path.is_file():
        raise HTTPException(status_code=404)
    return FileResponse(path, media_type=arquivo.mime_type)


@app.get("/", include_in_schema=False)
def dashboard(
    request: Request,
    usuario: Usuario = Depends(get_current_user),
    db: Session = Depends(get_session),
):
    """Dashboard (§10) — widgets condicionados às permissões do perfil."""
    permissoes = usuario.permissoes
    widgets = {}

    if "usuario.listar" in permissoes:
        widgets["usuarios"] = db.scalar(
            select(func.count()).select_from(Usuario).where(Usuario.deleted_at.is_(None))
        )
    if "empresa.listar" in permissoes:
        widgets["empresas"] = db.scalar(
            select(func.count()).select_from(Empresa).where(Empresa.deleted_at.is_(None))
        )
    if "auditoria.listar" in permissoes:
        widgets["eventos"] = db.scalar(select(func.count()).select_from(Auditoria))
        widgets["ultimos_eventos"] = list(
            db.scalars(select(Auditoria).order_by(Auditoria.id.desc()).limit(8))
        )
    if "log.listar" in permissoes:
        widgets["erros"] = db.scalar(
            select(func.count()).select_from(Log).where(Log.nivel.in_(["ERROR", "CRITICAL"]))
        )

    return render(request, "dashboard/index.html", usuario,
                  page_title="Dashboard", widgets=widgets)


discover_modules(app)
init_db()

from app.core.seeds import run_seeds  # noqa: E402  (após init_db)

run_seeds()
